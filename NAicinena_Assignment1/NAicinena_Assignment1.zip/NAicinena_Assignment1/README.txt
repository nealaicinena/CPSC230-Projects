Name
- Neal Aicinena
ID
- 2428026
Source Files:
- TotalPrice.py
- Celsius.py
- Quadratic.py
- Seconds.py
How to run your program/programs:
python3 Quadratic.py
python3 Seconds.py
python3 Quadratic.py
python3 TotalPrice.py
Sources:
- 
Collaborators:
