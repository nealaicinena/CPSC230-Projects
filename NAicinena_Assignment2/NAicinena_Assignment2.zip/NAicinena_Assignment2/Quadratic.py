from math import sqrt

#asks the user to input coefficients of a quadratic equation and stores them as variables
a = float(input("please enter first coefficient of quadratic: "))
b = float(input("please enter second coefficient of quadratic: "))
c = float(input("please enter third coefficient of quadratic: "))

#computes the first and second roots of the quadratic using the input from the user 
#!!this assumes that there are roots that exist for the function!!
root1 = (-b - sqrt((b ** 2) - (4 * a * c))) / (2 * a)
root2 = (-b + sqrt((b ** 2) - (4 * a * c))) / (2 * a)

#prints to the user both the roots or prints the same one twice if there is one root
print(root1, ",", root2)
