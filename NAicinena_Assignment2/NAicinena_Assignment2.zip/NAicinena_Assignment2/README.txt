Name
- Neal Aicinena

ID
- 2428026

Source Files:
- TotalPrice.py
- Quadratic.py

How to run your program/programs:
python3 Quadratic.py
python3 TotalPrice.py

Sources:
- 
Collaborators:
