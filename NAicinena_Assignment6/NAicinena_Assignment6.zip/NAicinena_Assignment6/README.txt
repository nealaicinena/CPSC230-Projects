Name
- Neal Aicinena

ID
- 2428026

Source Files:
- Wordle.py

How to run your program/programs:
python3 Wordle.py

Sources:
-https://stackoverflow.com/questions/1602934/check-if-a-given-key-already-exists-in-a-dictionary
-https://stackoverflow.com/questions/44205923/checking-if-word-exists-in-a-text-file-python
-https://www.w3schools.com/python/python_file_open.asp
-https://www.w3resource.com/python-exercises/python-basic-exercise-86.php
Collaborators:
-