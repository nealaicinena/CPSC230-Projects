Name
- Neal Aicinena

ID
- 2428026

Source Files:
- ExtraCredit.py

How to run your program/programs:
python3 ExtraCredit.py

Sources:
-https://www.geeksforgeeks.org/python-datetime-timedelta-class/
-https://www.geeksforgeeks.org/python-program-to-print-pascals-triangle/
-https://www.alpharithms.com/ascii-table-512119/
Collaborators:
-